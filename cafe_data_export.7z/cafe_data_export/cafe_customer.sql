-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: cafe
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `Customer_id` char(4) NOT NULL,
  `Customer_firstname` varchar(100) NOT NULL,
  `Customer_lastname` varchar(100) NOT NULL,
  `Customer_age` int NOT NULL,
  `Customer_points` int NOT NULL,
  `Customer_gender` varchar(10) NOT NULL,
  PRIMARY KEY (`Customer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES ('0001','จารุวรรณ','เหลืองสีนาค',20,5,'หญิง'),('0002','ศิรินทิพย์','ชัยชนะ',14,10,'ชาย'),('0003','ณัฐมน','สุขเกษม',37,14,'หญิง'),('0004','เจษฎา','กอวังตะโก',31,22,'หญิง'),('0005','จุฑาทิพย์','ชาญศิริ',34,13,'หญิง'),('0006','สุพรรษา','ประเสริฐสม',30,2,'หญิง'),('0007','นูรีซัน','สุขสันต์',29,3,'หญิง'),('0008','วลัยลักษณ์','สัตถาผล',28,1,'หญิง'),('0009','เบญจมาภรณ์','หมูนสี',27,8,'หญิง'),('0010','ฉันชนก','เชิญขวัญ',26,4,'หญิง'),('0011','ธันยพร','หะพันธ์',25,15,'หญิง'),('0012','อารีรัตน์','ศิริพันธ์',24,12,'หญิง'),('0013','สุนิสา','ศุขห่วง',23,3,'หญิง'),('0014','เกวลิน','จูเปาะ',22,11,'หญิง'),('0015','กัญญารัตน์','ประสพสุข',21,2,'หญิง'),('0016','จิรัชญา','เสนานุช',20,6,'หญิง'),('0017','พรรธิดา','สืบจันทร์',19,12,'หญิง'),('0018','จุฑาทิพย์','วัณเพชร',17,2,'หญิง'),('0019','อุสรา','เจ็กแตงพะเนา',37,5,'หญิง'),('0020','กัลยา','พานทอง',31,8,'หญิง'),('0021','รจนา','ขวัญเมือง',34,11,'ชาย'),('0022','กัณฑิมา','รามมีชัย',30,14,'ชาย'),('0023','กาญจนา','นาสร้อย',29,17,'ชาย'),('0024','พอฤทัย','ลาภผล',28,20,'ชาย'),('0025','วราภรณ์','แซ่ลิ่ม',27,11,'ชาย'),('0026','ธิดารัตน์','วงศ์เสน',26,2,'หญิง'),('0027','กรรณิการ์','คงอาษา',25,6,'ชาย'),('0028','แอนนา','สมบูรณ์สิงห์',24,23,'ชาย'),('0029','วริศรา','วงเวียน',23,35,'ชาย'),('0030','ภัสสร','ศรีน้ำเงิน',17,3,'ชาย');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-15 14:48:57
