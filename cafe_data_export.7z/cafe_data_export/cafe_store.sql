-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: cafe
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `store`
--

DROP TABLE IF EXISTS `store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `store` (
  `Store_ID` char(4) NOT NULL,
  `Store_name` varchar(50) NOT NULL,
  `Store_province` varchar(70) NOT NULL,
  PRIMARY KEY (`Store_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `store`
--

LOCK TABLES `store` WRITE;
/*!40000 ALTER TABLE `store` DISABLE KEYS */;
INSERT INTO `store` VALUES ('C001','Coffee\'s เซ็นทรัลพระราม3','กรุงเทพมหานคร'),('C002','Coffee\'s เซ็นทรัลพระราม9','กรุงเทพมหานคร'),('C003','Coffee\'s Centralนครราชสีมา','นครราชสีมา'),('C004','Coffee\'s เซ็นทรัลศรีราชา','ชลบุรี'),('C005','Coffee\'s เซ็นทรัลอยุธยา','พระนครศรีอยุธยา'),('C006','Coffee\'s Centralมหาชัย','สมุทรสาคร'),('C007','Coffee\'s เซ็นทรัลเชียงใหม่','เชียงใหม่'),('C008','Coffee\'s UnitedCenter(สีลม)','กรุงเทพมหานคร'),('C009','Coffee\'s สยามเซ็นเตอร์','กรุงเทพมหานคร'),('C010','Coffee\'s เซ็นจูรี่อนุสาวรีย์','กรุงเทพมหานคร'),('C011','Coffee\'s CentralWestgateบางใหญ่','กรุงเทพมหานคร'),('C012','Coffee\'s เซ็นทรัลเวิลด์','กรุงเทพมหานคร'),('C013','Coffee\'s CenterOneอนุสาวรีย์ชัยสมรภูมิ','กรุงเทพมหานคร'),('C014','Coffee\'s Centralสุราษฎร์ธานี','สุราษฎร์ธานี'),('C015','Coffee\'s Centralนครศรีธรรมราช','นครศรีธรรมราช'),('C016','Coffee\'s เซ็นทรัลลาดพร้าวชั้นG','กรุงเทพมหานคร'),('C017','Coffee\'s บิ๊กซีศรีนครินทร์','สมุทรปราการ'),('C018','Coffee\'s บิ๊กซีพัทยาใต้','ชลบุรี'),('C019','Coffee\'s บิ๊กซีอยุธยา','พระนครศรีอยุธยา'),('C020','Coffee\'s บิ๊กซีสุขาภิบาล3','กรุงเทพมหานคร'),('C021','Coffee\'s บิ๊กซีพระราม4','กรุงเทพมหานคร'),('C022','Coffee\'s บิ๊กซีราชดำริ','กรุงเทพมหานคร'),('C023','Coffee\'s บิ๊กซีนครปฐม','นครปฐม'),('C024','Coffe\'s บิ๊กซีมหาชัย','สมุทรสาคร'),('C025','Coffee\'s บิ๊กซีสุขาภิบาล5','กรุงเทพมหานคร'),('C026','Coffee\'s บิ๊กซีเชียงราย2','เชียงราย'),('C027','Coffee\'s บิ๊กซีบางพลี','สมุทรปราการ'),('C028','Coffee\'s บิ๊กซีเพชรเกษมextra','กรุงเทพมหานคร'),('C029','Coffee\'s ทาวน์เซ็นเตอร์บิ๊กซีหัวหมาก','กรุงเทพมหานคร'),('C030','Coffee\'s บิ๊กซีบางใหญ่','นนทบุรี');
/*!40000 ALTER TABLE `store` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-15 14:48:57
