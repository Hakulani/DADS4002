-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: cafe
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu` (
  `Menu_id` char(4) NOT NULL,
  `Menu_name` varchar(100) NOT NULL,
  `Menu_SellingPrice` int NOT NULL,
  `Menu_cost` int NOT NULL,
  `Menu_Type` varchar(20) NOT NULL,
  `Menu_Categories` varchar(50) NOT NULL,
  PRIMARY KEY (`Menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES ('0001','Espresso',35,20,'Hot','Coffee'),('0002','Espresso',55,25,'Cold','Coffee'),('0003','Espresso',60,30,'Frappe','Coffee'),('0004','Espresso Con Panna',45,25,'Hot','Coffee'),('0005','Espresso Con Panna',65,30,'Cold','Coffee'),('0006','Espresso Con Panna',70,35,'Frappe','Coffee'),('0007','Americano',50,30,'Hot','Coffee'),('0008','Americano',55,35,'Cold','Coffee'),('0009','Americano',60,40,'Frappe','Coffee'),('0010','Long Black',50,30,'Hot','Coffee'),('0011','Long Black',55,35,'Cold','Coffee'),('0012','Long Black',60,40,'Frappe','Coffee'),('0013','Latte',50,30,'Hot','Coffee'),('0014','Latte',65,35,'Cold','Coffee'),('0015','Latte',70,40,'Frappe','Coffee'),('0016','Piccolo',50,20,'Hot','Coffee'),('0017','Piccolo',55,25,'Cold','Coffee'),('0018','Piccolo',60,30,'Frappe','Coffee'),('0019','Cappuccino',45,25,'Hot','Coffee'),('0020','Cappuccino',60,30,'Cold','Coffee'),('0021','Cappuccino',65,35,'Frappe','Coffee'),('0022','Mocha',50,25,'Hot','Coffee'),('0023','Mocha',60,30,'Cold','Coffee'),('0024','Mocha',70,35,'Frappe','Coffee'),('0025','White Mocha',55,30,'Hot','Coffee'),('0026','White Mocha',65,35,'Cold','Coffee'),('0027','White Mocha',75,40,'Frappe','Coffee'),('0028','Macchiato',50,25,'Hot','Coffee'),('0029','Macchiato',60,30,'Cold','Coffee'),('0030','Macchiato',70,35,'Frappe','Coffee'),('0031','Caramel Macchiato',55,30,'Hot','Coffee'),('0032','Caramel Macchiato',65,35,'Cold','Coffee'),('0033','Caramel Macchiato',75,40,'Frappe','Coffee'),('0034','Italian soda',50,20,'Cold','Coffee'),('0035','Chocolate',45,25,'Hot','Coffee'),('0036','Chocolate',50,30,'Cold','Coffee'),('0037','Chocolate',55,35,'Frappe','Coffee'),('0038','Dark Chocolate',50,30,'Hot','Milk-Chocolate'),('0039','Dark Chocolate',55,35,'Cold','Milk-Chocolate'),('0040','Dark Chocolate',60,40,'Frappe','Milk-Chocolate'),('0042','Green Tea',40,15,'Hot','Tea'),('0043','Green Tea',45,20,'Cold','Tea'),('0044','Green Tea',50,25,'Frappe','Tea'),('0045','Milk Tea',45,20,'Hot','Tea'),('0046','Milk Tea',50,25,'Cold','Tea'),('0047','Milk Tea',55,30,'Frappe','Tea'),('0048','Thai Tea',45,20,'Hot','Tea'),('0049','Thai Tea',50,25,'Cold','Tea'),('0050','Thai Tea',55,30,'Frappe','Tea'),('0051','Mango Sticky Rice',100,60,'Dessert','Dessert'),('0052','Strawberry Pancake',150,90,'Dessert','Dessert'),('0053','Choc Banana Pancake',155,80,'Dessert','Dessert'),('0054','Macaron',120,80,'Dessert','Dessert'),('0055','Pudding',150,100,'Dessert','Dessert'),('0056','Butter Cake',120,100,'Dessert','Dessert'),('0057','Whole Wheat Bread',150,120,'Dessert','Dessert'),('0058','strawberry cheese pie',120,80,'Dessert','Dessert'),('0059','Blueberry Cheese Pie',150,100,'Dessert','Dessert'),('0060','Honey Toast',150,80,'Dessert','Dessert'),('0061','Toast',25,20,'Dessert','Dessert'),('0062','Waffle',50,30,'Dessert','Dessert'),('0063','Cheese cake',125,80,'Dessert','Dessert'),('0064','Custard Cake',60,40,'Dessert','Dessert'),('0065','Cookie',150,90,'Dessert','Dessert'),('0066','Brownie',80,50,'Dessert','Dessert'),('0067','Pancake',40,20,'Dessert','Dessert'),('0068','Banana Cake',40,20,'Dessert','Dessert'),('0069','Muffin',90,30,'Dessert','Dessert'),('0070','Cake Roll',45,20,'Dessert','Dessert'),('0071','Basque Cheesecake',250,100,'Dessert','Dessert');
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-15 14:48:57
